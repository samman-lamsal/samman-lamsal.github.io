MASARP STUDIO — PRESS KIT
Updated: October 2026
Website: https://masarpstudio.com
Contact: sammanlamsal31@gmail.com

Short description:
MASARP STUDIO is the independent game and software development brand of Samman Lamsal, based in Nepal. The catalogue spans original browser games, Facebook Instant Games and Android applications.

Creator: Samman Lamsal
Type: Independent developer brand (not presented as a registered company)
Location: Nepal
Focus: Game development, mobile apps, web applications, interactive experiences.

Selected titles:
Rival Guys — https://masarpstudio.com/games/rival-guys/
Hunter Strike — https://masarpstudio.com/games/hunter-strike/
Jelly Belly Clicker — https://masarpstudio.com/games/jelly-belly-clicker/
Be the Queen — https://masarpstudio.com/games/be-the-queen/
MomuBloom — https://masarpstudio.com/games/momubloom/

Branding: MASARP STUDIO wordmark/name and logo. Artwork included with this kit is provided for editorial, review and press coverage; no transfer of copyright.
Before publishing coverage, contact the studio for current game links, availability, assets and facts. Do not assume sales, download counts, or game availability.
